xmesh=[1,4,7];
ymesh=[1,3,7,8];
zmesh=[1,2,5,6,8];
msh=cartMesh(xmesh,ymesh,zmesh);
plotMesh(msh);
% Aufgabe 3

% Visualisierung eines Beispielgitters mit cartMesh und plotMesh

%% Beispielgitter definieren (3D)

% Erzeugen des Gitters

%% Darstellen des Gitters

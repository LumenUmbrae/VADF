% Aufgabe 4

% Methode zur Berechnung der C, S und St (S-Schlange) Matrizen
%
% Eingabe
% msh        Die Datenstruktur, die mit cartMesh erzeugt werden kann
%
% Rueckgabe
% c           Die C-Matrix des primaeren Gitters
% s           Die S-Matrix des primaeren Gitters
% st          Die S-Matrix des dualen Gitters

function [ c, s, st ] = geoMats( msh )

% Bestimmen von Mx, My, Mz sowie np aus struct msh


% Px Matrix erzeugen

% Py-Matrix erzeugen

% Pz-Matrix erzeugen

% Matrix derselben Groesse, gefuellt mit Nullen

% Aufbau der C, S und St Matrizen aus den P-Matrizen

end
% Berechnung der Materialmatrix Meps für elektrische Randbedingungen
% für die vorgegebenen Werte

%% Erzeugen des kartesischen Gitters
xmesh=[-2,0,2];
ymesh=[-1,0,1];
zmesh=[0,1];
%msh = cartMesh(        );

%% Erzeugen benötigter Geometriematrizen
% [DS, DSt] = createDS();
% DA = createDA();
% DAt = 

%% Permittivitäten für jedes Element festlegen
% eps_r =

%% Berechnen der Meps-Matrix
% bc =
% Deps = createDeps( msh, DA, DAt, eps_r, bc );
% Meps = createMeps( DAt, Deps, DS );
